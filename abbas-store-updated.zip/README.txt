Upload these files to the same GitHub Pages folder as index.html:
- index.html
- leather-wallet.jpg
- ronin-handsfree.jpg
- type-c-lead.jpg

Keep your existing FEECC2FA-9A69-48FD-B192-15335C3FB00C.png logo file in the same folder.
